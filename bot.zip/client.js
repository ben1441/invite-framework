import { MongoClient } from 'mongodb';


const mongo = new MongoClient('mongodb+srv://manovahb:Ben1441@cluster0.f9ktyol.mongodb.net/?retryWrites=true&w=majority');
const db = mongo.db('ccxt');

class Client {  
    update = async (name, value) => {
        return await db.collection('bot').updateOne({_id: name}, {$set: value});
    }

    get = async (name) => {
        const res = await db.collection('bot').find({_id: name}).toArray();
        return res[0];
    }

    set = async (value) => {
        return await db.collection('bot').insertOne(value)
    }
}

export { Client };