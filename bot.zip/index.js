import { Scenes, session, Markup, Telegraf } from 'telegraf';
const { enter, leave } = Scenes.Stage;
import C from './ccxt.js';
import { binance } from 'ccxt';
import { Client } from './client.js';

(async () => {
  const c = new C();
  const client = new Client();
  const bot = new Telegraf('6018045777:AAFqECIa9lZYcksYsT7lQgRJM4l2AhPKL9g');
  //bot.use(Telegraf.log());

  const tocScene = new Scenes.BaseScene('tocScene');
  const excScene = new Scenes.BaseScene('excScene');

  const stage = new Scenes.Stage([tocScene, excScene], { ttl: 10 });

  const clear = ctx => {
    /*console.log(ctx)
    ctx.deleteMessage(ctx.message.message_id - 1)*/
  }
  const main = Markup.inlineKeyboard([
    [Markup.button.callback('Exchanges', 'exc')],
    [Markup.button.callback('Token', 'toc'), Markup.button.callback('prices', 'getPrices')]
  ]);
  const back = Markup.inlineKeyboard([
    Markup.button.callback('Back', 'main')
  ]);

  bot.use(session());
  bot.use(stage.middleware());

  bot.start(ctx => ctx.replyWithMarkdown("*Hi There*,\nThis is an _Arbitrage_ bot", main))

  bot.action('exc', async ctx => {
    clear(ctx);
    let exc = await client.get('exc');
    //console.log(exc)
    ctx.replyWithMarkdown('*The following Exchanges are in the list:* \n' + ((!exc) ? 'You currently dont have any exchanges listed here.\nClick below to add few' : '`' + exc.join('\n') + '`'), Markup.inlineKeyboard([
      Markup.button.callback('set Exchanges', 'setExc'),
      Markup.button.callback('Back', 'main')
    ]))
  });

  bot.action('main', ctx => ctx.replyWithMarkdown('*Hi There*,\nThis is an _Arbriage_ bot', main));

  bot.action('toc', async ctx => {
    clear(ctx);
    let toc = await client.get('toc');
    ctx.replyWithMarkdown((!toc) ? 'No token is specified here\nClick below to set a coin/token' : '*Token/coin pair:* `' + toc + '`', Markup.inlineKeyboard([
      Markup.button.callback('set Token', 'setToc'),
      Markup.button.callback('Back', 'main')
    ]));
  });

  bot.action('getPrices', async ctx => {
    clear(ctx);
    ctx.replyWithMarkdown("`[*] processing...` \n`[+] Usually takes 5-10 seconds to be completed`")
    const toc = await client.get('toc');
    const exc = await client.get('exc');
    if (!exc || !toc) {
      ctx.reply('Either token/coin or exchanges are not set')
    } else {
      let price = {};
      for (i in exc)
        price[exc[i]] = await c.getPrice(exc[i], toc);
      let txt = '';
      for (key in price)
        txt += '*' + key + ':* `' + price[key] + '`\n';
      ctx.replyWithMarkdown(txt, back);
      const priceAsc = Object.entries(price).sort((a, b) => a[1] - b[1]);
      const priceDesc = Object.entries(price).sort((a, b) => b[1] - a[1]);
      ctx.replyWithMarkdown("_ALERT!!!_\n\n*Opportunity found*\n\nExchange with lowest `" + toc + "` price: \n`" + priceAsc[0][0] + "`\nExchange with highest `" + toc + "` price: \n`" + priceDesc[0][0] + "`");
    }
  });

  bot.action('setToc', ctx => {
    clear(ctx);
    ctx.reply('Enter the coin/token you want to see the price for -');
    ctx.scene.enter('tocScene');
  });

  tocScene.on('message', async ctx => {
    clear(ctx);
    const toc = ctx.message.text.toUpperCase();
    await client.set('toc', toc);
    ctx.replyWithMarkdown('*Token/Coin* `pair` successfully set to `' + toc, back + '`');
    ctx.scene.leave('tocScene');
  });

  bot.action('setExc', ctx => {
    clear(ctx);
    ctx.reply('Enter the list of exchanges separated by a space -');
    ctx.scene.enter('excScene');
  });

  excScene.on('message', async ctx => {
    clear(ctx);
    const exc = ctx.message.text.toLowerCase().split(' ');
    await client.set('exc', exc);
    ctx.replyWithMarkdown('*The exchanges are* \n`' + exc.join('\n') + '`', back);
    ctx.scene.leave('excScene')
  })

  bot.command('execute', async ctx => {
    const exc = await client.get('exc');
    const toc = await client.get('toc');
    const exchange = new binance({
      apiKey: process.env.API_KEY,
      secret: process.env.API_SECRET,
      enableRateLimit: true
    });
    const fee = 0.001;
    ctx.reply('NOTE: This is an estimation of a trade. This is executed on binance exchange.');
    const price = await c.getPrice('binance', toc);
    const amount = 1000;
    const side = 'buy';
    const type = 'limit';
    const order = await exchange.createOrder(toc, type, side, amount, price)
    console.log(order);
  });

  bot.launch();
})();