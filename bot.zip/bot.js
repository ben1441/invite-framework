import { binance as _kucoin } from 'ccxt';
import TelegramBot from 'node-telegram-bot-api';

const kucoin = new _kucoin({
    apiKey: 'Evyzdmj1t8fF7xnwj5tYpB2LiJYtbEJ2vKDIiEor3xSFatVmTVn47M0qBGeH5oYw', //'L3T8yLdRtu9xnhSc2ZrweOPVQoyzpdEvxX1uDmRORS1JSv400ydsXByUPmtjnoVW',
    secret: 'WUxymcpxlMK75QLR8gTpkGnkCGYJdssShaWaMXzXSpHXjOIMEwXHoM3ifD8B8hyV', //'dgkpQLNGIRXZqd0uBJIu9VQmR1FKuYR4Gaa3y62UAzN5vLJHnr4S7tMjMMHD8TdF',
});

kucoin.setSandboxMode(true);

const telegramToken = '6018045777:AAFqECIa9lZYcksYsT7lQgRJM4l2AhPKL9g';
const bot = new TelegramBot(telegramToken, { polling: true });

(async() => {
    await kucoin.loadMarkets();
})();

bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const menuOptions = {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Start Arbitrage', callback_data: 'start_arbitrage' }],
            ],
        },
    };
    bot.sendMessage(chatId, 'Welcome to the Triangular Arbitrage Bot! Choose an option:', menuOptions);
});

bot.on('callback_query', async(callbackQuery) => {
    const action = callbackQuery.data;
    const chatId = callbackQuery.message.chat.id;

    if (action === 'start_arbitrage') {
        bot.sendMessage(chatId, 'Please enter the amount you want to use for arbitrage (in USDT):');
        bot.once('message', async(msg) => {
            const amount = parseFloat(msg.text);
            if (isNaN(amount) || amount <= 0) {
                bot.sendMessage(chatId, 'Invalid amount. Please enter a positive number.');
                return;
            }

            try {
                const symbols = ['ETH/BTC', 'ETH/USDT', 'BTC/USDT'];

                // Check if all trading pairs are available on KuCoin
                // kucoin.loadMarkets()
                //     .then(i => {
                //         for(let key in i) {
                //             console.log(key)
                //         }
                //     });
                symbols.forEach(async (symbol) => console.log(kucoin.fetchTicker(symbol)));
                const availableSymbols = symbols.every((symbol) => kucoin.markets[symbol]);
                if (!availableSymbols) {
                    console.log(availableSymbols)
                    bot.sendMessage(chatId, 'One or more trading pairs are not available on KuCoin. Please try a different exchange or trading pair.');
                    return;
                }

                const tickers = [];
                for (const symbol of symbols) {
                    await new Promise((resolve) => setTimeout(resolve, kucoin.rateLimit));
                    const ticker = await kucoin.fetchTicker(symbol);
                    tickers.push(ticker);
                }
                console.log(tickers)

                const btcEthRate = tickers[0].ask;
                const ethUsdtRate = tickers[1].ask;
                const btcUsdtRate = tickers[2].ask;

                const expectedBtcUsdtRate = ethUsdtRate / btcEthRate;
                console.log(btcUsdtRate, btcEthRate, ethUsdtRate, expectedBtcUsdtRate)

                if (Math.abs(btcUsdtRate - expectedBtcUsdtRate) > 0.01) {
                    bot.sendMessage(chatId, `Arbitrage opportunity detected. Executing trades with ${amount} USDT...`);

                    // Trade execution logic
                    const amountInUsdt = amount;
                    const ethAmount = amountInUsdt / ethUsdtRate;
                    const btcAmount = ethAmount / btcEthRate;

                    // Execute ETH/USDT trade (buy ETH with USDT)
                    await kucoin.createMarketOrder('ETH/USDT', 'buy', ethAmount);

                    // Execute BTC/ETH trade (buy BTC with ETH)
                    await kucoin.createMarketOrder('ETH/BTC', 'buy', btcAmount);

                    // Execute BTC/USDT trade (sell BTC for USDT)
                    await kucoin.createMarketOrder('BTC/USDT', 'sell', btcAmount);

                    bot.sendMessage(chatId, 'Arbitrage trades executed successfully.');
                } else {
                    bot.sendMessage(chatId, 'No arbitrage opportunity found.');
                }
            } catch (error) {
                console.error(error);
                bot.sendMessage(chatId, 'An error occurred while checking for arbitrage opportunities. Please try again later.');
            }
        });
    }
});