const axios = require('axios');
const input = require('input');

(async () => {
  const chain = await input.text('chain :');
  const op = await input.text('method (sendTransaction or sendToken): ');
  const pk = await input.text('private key: ');
  const to = await input.text('to: ');
  const amount = await input.text('amount: ');
  const data = {
    privateKey: pk,
    to: to,
    amount: amount
  }
  if(op=='sendToken') {
    const ca = await input.text('token contract address: ')
    data.contractAddress = ca;
  }
  const url = 'https://api-4xyk.onrender.com'
  const res = await axios.post(url+'/'+chain+'/'+op, data);
  console.log(res.data);
})();