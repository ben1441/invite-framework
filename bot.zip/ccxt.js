const ccxt = require('ccxt');

class Ccxt {
  constructor() { };

  async getPrice(exchangeId, symbol) {
    const exchange = new ccxt[exchangeId]();
    const ticker = await exchange.fetchTicker(symbol);
    return ticker.last;
  }

  async getPrices(exchanges, symbol) {
    const prices = {};
    for (const exchange of exchanges) {
      try {
        const price = await this.getPrice(exchange, symbol);
        prices[exchange] = price;
      } catch (error) {
        console.error(`Failed to get price on ${exchange}: ${error.message}`);
      }
    }
    return prices;
  }
}

module.exports = Ccxt;