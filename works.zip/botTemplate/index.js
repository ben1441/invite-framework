import { Telegraf, Scenes, Markup } from 'telegraf';
import dotenv from 'dotenv';

import start from './commands/start.js';
import account from './commands/account.js';
import btn from './commands/btn.js';
import invite from './commands/invite.js';
import faucet from './commands/faucet.js';
import balance from './commands/balance.js';
import task from './commands/task.js';
import wallet from './commands/wallet.js';


dotenv.config();

const { BaseScene, Stage } = Scenes;
const {enter, leave} = Stage;
const stage = new Stage();
const Scene = BaseScene;

(async () => {
    const bot = new Telegraf(process.env.BOT_TOKEN);

    bot.start(start);

    bot.hears(btn.account, account)

    bot.hears(btn.back, start)

    bot.hears(btn.invite, invite)    

    bot.hears(btn.faucet, faucet)

    bot.hears(btn.balance, balance)

    bot.hears(btn.task, task)

    bot.hears(btn.wallet, wallet)
    
    bot.launch();
})();

