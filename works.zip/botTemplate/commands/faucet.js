import dotenv from 'dotenv'
import { Client } from './client.js';

const client = new Client();
dotenv.config();

const faucet = async (ctx) => {
    const Faucet = process.env.FAUCET;
    const currency = process.env.CURRENCY;
    const prev = await client.get('user/'+ctx.from.id);
    if(!prev || !prev.faucet) {
        ctx.replyWithHTML(
            `<pre>🔴 🟡 🟢\n\n +${Faucet} ${currency} received</pre>`
        )
        await client.update('user/'+ctx.from.id, {faucet: Date.now()});
        if(!prev.balance) {
            await client.update('user/'+ctx.from.id, {balance: parseInt(Faucet)});
        } else {
            await client.update('user/'+ctx.from.id, {balance: parseInt(prev.balance) + parseInt(Faucet)});
        }
    } else {
        const time = Date.now() - prev.faucet;
        const timeLeft = (60*60*24*1000) - time;
        if(timeLeft >= 0) {
            const seconds = Math.floor(timeLeft/1000);
            const minutes = Math.floor(seconds/60);
            const hours = Math.floor(minutes/60);
            ctx.replyWithHTML(
                `<pre>🔴 🟡 🟢\n\n You can claim again in \n | ${hours % 24} hours\n | | ${minutes % 60} minutes\n | | | ${seconds % 60} seconds</pre>`
            );
        } else {
            ctx.replyWithHTML(
                `<pre>🔴 🟡 🟢\n\n +${Faucet} ${currency} received</pre>`
            )
            await client.update('user/'+ctx.from.id, {faucet: Date.now()});
            const balance = (await client.get('user/'+ctx.from.id)).balance; 
            await client.update('user/'+ctx.from.id, {balance: parseInt(balance) + parseInt(Faucet)});
        }
    }
    
}

export default faucet