import { Markup } from 'telegraf';
import { Client } from './client.js';

const client = new Client();

const wallet = async (ctx) => {
    let data = await client.get('user/'+ctx.from.id);
    let wallet = (!data.wallet) ? 'Not set' : data.wallet;
    ctx.replyWithHTML(
        `<pre>🔴 🟡 🟢\n\n Greetings ${ctx.from.first_name}\n | Your Wallet:\n | | ${wallet}</pre>`,
        Markup.inlineKeyboard([
            [Markup.button.callback('Set Wallet', 'setWallet')],
        ])
    );
}

export default wallet;