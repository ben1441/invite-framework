const task = (ctx) => {
    ctx.replyWithHTML(
        `<pre>🔴 🟡 🟢\n\n Greetings ${ctx.from.first_name}\n | Welcome to Task section\n | Complete tasks to earn bonus</pre>`
    )
}

export default task;