import dotenv from 'dotenv'
import { Client } from './client.js';

const client = new Client();
dotenv.config();

const invite = async (ctx) => {
    let data = await client.get('user/'+ctx.from.id)
    let invites;
    if (!data || !data.invites ) invites = 0;
    ctx.replyWithHTML(
        `<pre>🔴 🟡 🟢\n\n ${ctx.from.first_name}\n\n </pre><b>Your total Refers: <pre>${invites}\n </pre>Invite more friends to earn</b><pre>\n\n https://t.me/${process.env.BOT_NAME}?start=${ctx.from.id}</pre>`
    )
}

export default invite;