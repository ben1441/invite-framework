const btn = {
    account: '🏦 Account',
    wallet: '👛 Wallet',
    balance: '💶 Balance',
    faucet: '🌀 Faucet',
    task: '🍥 Task',
    invite: '🤝 Invite',
    withdraw: '💰 Withdraw',
    back: '🔙 Back'
}

export default btn