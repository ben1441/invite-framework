import { Scenes } from 'telegraf';
const {enter, leave} = Scenes.Stage;
const stage = new Scenes.Stage();
const Scene = Scenes.BaseScene;

const register= (name) => {
    const scene = new Scene(name);
    stage.register(scene); 
    return scene;
}

export default register