/**
 * @param {string} method
 * @param {object} data
*/

import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const withdrawClient = async (method, data) => {
    const response = await axios.post(process.env.URI+method, data);
    return response.data;
}

export default withdrawClient;