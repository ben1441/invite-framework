import { Markup } from 'telegraf';
import btn from './btn.js';
import { Client } from './client.js'

const client = new Client();

const start = async (ctx) => {
    const user = await client.get('user/'+ctx.from.id);
    if(!user)
        await client.set({_id: 'user/'+ctx.from.id});
    ctx.replyWithHTML(
        '<pre>🔴 🟡 🟢\n\n Hi '+ctx.from.first_name+'\n Welcome to Template Bot</pre>', 
        Markup.keyboard([
            [btn.account],
            [btn.invite, btn.withdraw],
            [btn.faucet, btn.task]
        ])
          .resize()
    )
};

 export default start