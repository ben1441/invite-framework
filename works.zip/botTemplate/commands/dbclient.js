import { MongoClient } from 'mongodb';
import dotenv from 'dotenv';

dotenv.config();

const mongo = new MongoClient(process.env.URI);
const db = mongo.db(process.env.BOT_TOKEN.split(':')[0]);

class Client {  
    update = async (name, value) => {
        return await db.collection('bot').updateOne({_id: name}, {$set: value});
    }

    get = async (name) => {
        const res = await db.collection('bot').find({_id: name}).toArray();
        return res[0];
    }

    set = async (value) => {
        return await db.collection('bot').insertOne(value)
    }
}

export { Client };