import { Client } from './clientjs';
import dotenv from 'dotenv'
import { Markup } from 'telegraf';
import register from './scenejs' 
import withdrawClient from './withdrawClientjs';

dotenv.config();

const client = new Client();

const withdraw = async (ctx) =>  {
    const user = await client.get('user/' + ctx.from.id);
    if(!user.balance) {
        ctx.replyWithHTML(
            `<pre>🔴 🟡 🟢\n\n You don't have any balance</pre>`
        );
    } else {
        ctx.replyWithHTML(
            `<pre>🔴 🟡 🟢\n\n Your balance: ${user.balance}</pre>`
        );
        ctx.replyWithHTML(
            `<pre>🔴 🟡 🟢\n\n Enter amount to withdraw</pre>`
        );
        const scene = register('withdraw');
        ctx.scene.enter('withdraw');

        scene.hear(/^[0-9]+$/, async (ctx) => {
            const amount = ctx.message.text;
            if(amount > user.balance) {
                ctx.replyWithHTML(
                    `<pre>🔴 🟡 🟢\n\n You don't have enough balance</pre>`
                );
            } else {
                if(!user.address) {
                    ctx.replyWithHTML(
                        `<pre>🔴 🟡 🟢\n\n Your wallet address is \n not set.\n Please come back after\n setting your address</pre>`
                    );
                    ctx.scene.leave('withdraw');
                } else {
                    const res = withdrawClient(
                        process.env.CHAIN+'/'+process.env.METHOD,
                        {
                            to: user.address,
                            amount: amount,
                            privateKey: process.env.PK
                        }
                    );
                }
            }
        });
    }
}