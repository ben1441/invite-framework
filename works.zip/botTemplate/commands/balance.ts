import { Client } from "./client.ts";
import dotenv from "dotenv";

const client = new Client();
dotenv.config();

const balance = async (ctx) => {
    const data = await client.get('user/'+ctx.from.id);
    let balance;
    balance = (!data || !data.balance) ? 0 : data.balance;
    ctx.replyWithHTML(
        `<pre>🔴 🟡 🟢\n\n Greetings ${ctx.from.first_name}\n | Your current Balance is -\n | | ${balance} ${process.env.CURRENCY}</pre>`
    )
};

export default balance;