import { Markup } from 'telegraf';
import btn from './btn.js'

const account= async (ctx) => {
    ctx.replyWithHTML(
        `<pre>🔴 🟡 🟢\n\n ${ctx.from.first_name}\n -Your Account details.\n | Available Actions:\n | | [${btn.balance}]\n | | [${btn.wallet}]</pre>`,
        Markup.keyboard([
            [btn.balance, btn.wallet],
            [btn.back]
        ])
        //   .oneTime()
          .resize()
    )
}

export default account;